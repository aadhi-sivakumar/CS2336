public class EventException extends RuntimeException
{
    public EventException(String message)
    {
        // add print statement explaining exception
        super(message);
    }
}
